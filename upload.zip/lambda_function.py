# coding: UTF-8
import requests
import json
import os
import logging

post_url = 'https://hooks.slack.com/services/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'

def check_review_request(event):
    # ReviewRequestかどうかチェック
    if event.get('action') == 'review_requested':
        return True
    else:
        return False

def open_jsonfile(path):
    # json設定ファイル読み込み
    with open(path, 'r') as f:
        return json.loads(f.read(),'utf-8')


def mapping_account(event):
    # githubとslackアカウントを紐づけ
    if check_review_request(event) is True:
        github_name = event['pull_request']['requested_reviewers'][0]['login']
        settingData = open_jsonfile('lambda.json')
        for i in settingData['reviewers']:
            if i == github_name:
                return settingData['slackUsers'][i]

def message(path):
    settingData = open_jsonfile(path)
    return settingData['message']['requestReview']

def post_slack(event, context):
     # slack送信
     username = mapping_account(event)
     message = message('lambda.json')
     requests.post(post_url, data = json.dumps({
            'text': '@{} {}'.format(username, message), # 投稿するテキスト
            'username': 'github', # 投稿のユーザー名
            'link_names': 1, # メンションを有効にする
            'channel': 'github_to_slack', # チャンネル
            'icon_emoji': 'icon', # アイコン
        }))

def lambda_handler(event, context):
    # TODO implement
    post_slack(event, context)
    return { 'statusCode': 200, 'body': json.dumps(event) }
